<?php
// Start the session
session_start();

// Destroy all session data
$_SESSION = [];
session_unset();
session_destroy();

// Redirect to the login page with an alert message
echo "<script>
    alert('Kamu berhasil keluar.');
    window.location.href = 'index.php';
</script>";
exit;
?>
