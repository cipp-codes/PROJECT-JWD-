<?php
require_once "koneksi.php";
session_start();

// Get the username and password from POST request
$username = trim($_POST['username']);
$password = trim($_POST['password']);

// Sanitize the input to prevent SQL injection
$sanitized_username = mysqli_real_escape_string($koneksi, $username);
$hashed_password = mysqli_real_escape_string($koneksi, md5($password));

// Prepare and execute the SQL query
$sql = "SELECT * FROM tbl_admin WHERE username = '$sanitized_username' AND password = '$hashed_password'";
$result = mysqli_query($koneksi, $sql);

// Check if any rows were returned
if (mysqli_num_rows($result) > 0) {
    $user_data = mysqli_fetch_assoc($result);

    // Set session variables
    $_SESSION['namaadmin'] = $user_data['nama_admin'];
    $_SESSION['username'] = $user_data['username'];
    $_SESSION['password'] = $user_data['password'];
    $_SESSION['idadmin'] = $user_data['id_admin'];

    // Handle the "remember me" functionality
    if (isset($_POST["remember"]) && $_POST["remember"] === 'on') {
        setcookie("username", $username, time() + 5 * 24 * 60 * 60); // 5 days
        setcookie("password", $password, time() + 5 * 24 * 60 * 60); // 5 days
    } else {
        if (isset($_COOKIE["username"])) {
            setcookie("username", "", time() - 3600); // Delete the cookie
        }
        if (isset($_COOKIE["password"])) {
            setcookie("password", "", time() - 3600); // Delete the cookie
        }
    }

    // Redirect to dashboard
    header("Location: dashboard.php?hal=beranda");
    exit;
} else {
    // Set session error message
    $_SESSION['error_message'] = "Nama Pengguna atau Kata Sandi Anda Salah!";
    // Redirect to index.php
    header("Location: index.php");
    exit;
}
