<?php
  require_once "koneksi.php";
  date_default_timezone_set('Asia/Jakarta');
  session_start();
  if(empty($_SESSION['username']) and empty($_SESSION['password'])){
    echo'
    <center>
    <br><br><br><br><br><br><br><br><br><br>
    <b>Maaf, Silahkan Masuk!</b><br><br>
    <b>Anda Telah Keluar Dari Sistem</b><br>
    <b>Atau Anda Belum Masuk</b><br>

    <a href="index.php" title="Klik Gambar Ini Untuk Kembali Masuk"><img src="kunci.png" heigth="100" width="100"></img></a>
    </center>
    ';
  }else{

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Dashboard - <?php echo ucwords(str_replace('_',' ',$_GET['hal'])) ?></title>

    <!-- Bootstrap CSS -->
    <script src="https://cdn.tiny.cloud/1/du2ji08u9j975eau9z1frbc47sneirxgh0q1lv2uykbgrix1/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.4/css/dataTables.dataTables.css">
    
    <style>
      /* Additional CSS to control layout */
      .sidebar {
        padding-top: 20px;
      }
      .stats-container {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #ccc;
      }

    
      .custom-bg {
        background-color: #1E90FF; /* Warna biru kustom yang diinginkan */
      }

      .btn-custom {
        background-color: #002F6C; /* Warna biru yang lebih gelap untuk tombol */
        color: white;
      }

      .btn-custom:hover {
        background-color: #B0E0E6; /* Warna saat tombol di-hover */
      }

    </style>
  </head>
  <body class="bg-secondary">
    <div class="container-fluid">
      <!-- start header -->
      <div class="row">
        <div class="col-lg-12 py-2 custom-bg fixed-top">
          <div class="dropdown float-right">
            <button class="btn btn-custom dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">Pengguna</button>
            <div class="dropdown-menu dropdown-menu-right">
              <a class="dropdown-item" href="">
                <div class="media">
                  <img src="foto/logo.png" height="50" width="50" class="align-self-center mr-3" alt="...">
                  <div class="media-body">
                    <h5 class="mt-0"><i class="bi bi-person-fill"></i> <?php echo $_SESSION['namaadmin'] ?></h5>
                    <small><p class="mb-0"><i class="bi bi-clock"></i> Pukul <?php echo date('H:i:s')?> WIB</p></small>
                  </div>
                </div>
              </a>
              <a class="dropdown-item" href="dashboard.php?hal=user"><i class="bi bi-gear"></i> Pengaturan</a>
              <a class="dropdown-item" href="logout.php" onclick="return confirm('Apakah anda yakin ingin keluar?')"><i class="bi bi-box-arrow-right"></i> Keluar</a>
            </div>
          </div>
        </div>
      </div>
      <!-- end header -->

      <!-- start content -->
<div class="container-fluid mt-4" style="padding-top:50px">
  <!-- Horizontal navbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light rounded-navbar">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item <?php echo ($_GET['hal'] == 'beranda') ? 'active' : ''; ?>">
          <a class="nav-link" href="dashboard.php?hal=beranda">Beranda</a>
        </li>
        <li class="nav-item <?php echo ($_GET['hal'] == 'tentang') ? 'active' : ''; ?>">
          <a class="nav-link" href="dashboard.php?hal=tentang">Tentang Kami</a>
        </li>
        <li class="nav-item <?php echo (($_GET['hal'] == 'galeri') or ($_GET['hal'] == 'tambah_galeri') or ($_GET['hal'] == 'edit_galeri')) ? 'active' : ''; ?>">
          <a class="nav-link" href="dashboard.php?hal=galeri">Galeri</a>
        </li>
        <li class="nav-item <?php echo (($_GET['hal'] == 'wisata') or ($_GET['hal'] == 'tambah_wisata') or ($_GET['hal'] == 'edit_wisata')) ? 'active' : ''; ?>">
          <a class="nav-link" href="dashboard.php?hal=wisata">Wisata</a>
        </li>
        <li class="nav-item <?php echo (($_GET['hal'] == 'kategori') or ($_GET['hal'] == 'tambah_kategori') or ($_GET['hal'] == 'edit_kategori')) ? 'active' : ''; ?>">
          <a class="nav-link" href="dashboard.php?hal=kategori">Kategori</a>
        </li>
        <li class="nav-item <?php echo (($_GET['hal'] == 'berita') or ($_GET['hal'] == 'tambah_berita')) ? 'active' : ''; ?>">
          <a class="nav-link" href="dashboard.php?hal=berita">Berita</a>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Main content -->
  <div class="row mt-4">
    <div class="col-lg-12">
      <?php
        if(isset($_GET['hal'])){
          switch($_GET['hal']){
            case 'beranda':
              include "modul/modulberanda/beranda.php";
              break;
            case 'tentang':
              include "modul/modultentang/tentang.php";
              break;
            case 'galeri':
              include "modul/modulgaleri/galeri.php";
              break;
            case 'tambah_galeri':
              include "modul/modulgaleri/tambah_galeri.php";
              break;
            case 'edit_galeri':
              include "modul/modulgaleri/edit_galeri.php";
              break;
            case 'hapus_galeri':
              include "modul/modulgaleri/hapus_galeri.php";
              break;
            case 'wisata':
              include "modul/modulwisata/wisata.php";
              break;
            case 'tambah_wisata':
              include "modul/modulwisata/tambah_wisata.php";
              break;
            case 'edit_wisata':
              include "modul/modulwisata/edit_wisata.php";
              break;
            case 'hapus_wisata':
              include "modul/modulwisata/hapus_wisata.php";
              break;
            case 'kategori':
              include "modul/modulkategori/kategori.php";
              break;
            case 'tambah_kategori':
              include "modul/mod_kategori/tambah_kategori.php";
              break;
            case 'edit_kategori':
              include "modul/modulkategori/edit_kategori.php";
              break;
            case 'hapus_kategori':
              include "modul/modulkategori/hapus_kategori.php";
              break;
            case 'berita':
              include "modul/modulberita/berita.php";
              break;
            case 'tambah_berita':
              include "modul/modulberita/tambah_berita.php";
              break;
            case 'hapus_berita':
              include "modul/modulberita/hapus_berita.php";
              break;
            case 'user':
              include "modul/moduluser/user.php";
              break;
            default:
              echo "<h3>Halaman Tidak Di Temukan</h3>";
          }
        } else {
          header("location:dashboard.php?hal=home");
        }
      ?>
    </div>
  </div>
</div>
<!-- end content -->

<!-- Custom CSS -->
<style>
  .rounded-navbar {
    border-radius: 30px; /* Atur nilai sesuai kebutuhan */
    overflow: hidden; /* Pastikan konten tidak melampaui rounded corners */
  }

  .navbar-nav .nav-link {
    color: black !important;
    background-color: white !important;
    padding: 10px 20px; /* Spasi di dalam tombol */
    border-radius: 20px; /* Membulatkan sudut item navbar */
    margin: 0 10px; /* Jarak antar item */
  }

  .navbar-nav .nav-item.active .nav-link,
  .navbar-nav .nav-link:hover {
    color: blue !important;
    background-color: white !important;
    border-radius: 20px; /* Pastikan sudut membulat saat hover atau aktif */
  }
</style>



    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
    

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    
    <!-- <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script> -->

    <script>
      tinymce.init({
        selector: 'textarea',
        plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange export formatpainter pageembed linkchecker a11ychecker tinymcespellchecker permanentpen powerpaste advtable advcode editimage advtemplate ai mentions tinycomments tableofcontents footnotes mergetags autocorrect typography inlinecss markdown',
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
        tinycomments_mode: 'embedded',
        tinycomments_author: 'Author name',
        mergetags_list: [
          { value: 'First.Name', title: 'First Name' },
          { value: 'Email', title: 'Email' },
        ],
        ai_request: (request, respondWith) => respondWith.string(() => Promise.reject("See docs to implement AI Assistant")),
      });
    </script>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.1.4/js/dataTables.js"></script>
    <script>
      const table = new DataTable('#example', {
        columnDefs: [
            {
                searchable: false,
                orderable: false,
                targets: 0
            }
        ],
        order: [[1, 'asc']]
    });
    
    table
        .on('order.dt search.dt', function () {
            let i = 1;
    
            table
                .cells(null, 0, { search: 'applied', order: 'applied' })
                .every(function (cell) {
                    this.data(i++);
                });
        })
      .draw();
    </script>
  </body>
</html>
<?php
}
?>