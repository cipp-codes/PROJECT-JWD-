<div class="container-fluid">
    <div class="card" style="border: 1px solid #ccc; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
        <div class="card-header" style="background-color: #002F6C; color: white; border-bottom: 1px solid #ddd; padding: 15px;">
            <strong>Ubah Konten Tentang Kami</strong>
        </div>
        <div class="card-body" style="padding: 20px;">
            <?php
                $sql = mysqli_query($koneksi, "SELECT * FROM tbl_tentang");
                $r = mysqli_fetch_array($sql);
            ?>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group" style="margin-bottom: 20px;">
                  <label for="konten_tentang" style="font-weight: bold; color: #333;">Konten Tentang Kami</label>
                  <textarea class="form-control" name="konten_tentang" id="konten_tentang" rows="10" style="border: 1px solid #ddd; border-radius: 5px;"><?php echo $r['konten_tentang'] ?></textarea>
                </div>
                <div class="form-group" style="margin-bottom: 20px;">
                  <label for="foto_tentang" style="font-weight: bold; color: #333;">Foto Tentang Kami</label>
                  <input type="file" class="form-control-file" name="foto_tentang" id="foto_tentang" placeholder="" aria-describedby="fileHelpId" style="border: 1px solid #ddd; border-radius: 5px;">
                  <small id="fileHelpId" class="form-text text-muted" style="font-size: 0.9em;">Upload File Image (jpg, jpeg, png)</small>
                </div>
                <div class="form-group" style="margin-bottom: 20px;">
                    <img src="././foto_tentang/<?php echo $r['foto_tentang'] ?>" alt="<?php echo $r['foto_tentang'] ?>" height="100" width="100" style="border: 1px solid #ddd; border-radius: 5px;">
                </div>
                <button type="submit" name="submit" class="btn" style="background-color: #002F6C; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; transition: background-color 0.3s;" onmouseover="this.style.backgroundColor='#001A4D'" onmouseout="this.style.backgroundColor='#002F6C'">Update</button>
            </form>

            <?php
            if(isset($_POST['submit'])) {
                $konten_tentang = $_POST['konten_tentang'];
                $id_tentang = $r['id_tentang'];

                $foto_tentang = $_FILES['foto_tentang']['name'];
                $path_foto_tentang = "././foto_tentang/".$r['foto_tentang'];

                $file_extension = array('png', 'jpg', 'jpeg', 'gif');
                $extension = pathinfo($foto_tentang, PATHINFO_EXTENSION);
                $size_foto_tentang = $_FILES['foto_tentang']['size'];
                $rand = rand();

                if(empty($foto_tentang)) {
                    mysqli_query($koneksi, "UPDATE tbl_tentang SET konten_tentang='$konten_tentang' WHERE id_tentang='$id_tentang'");
                    echo "<script>alert('Konten Tentang Kami Berhasil Di Ubah!'); window.location = 'dashboard.php?hal=tentang'</script>";
                } else {
                    if (!in_array($extension, $file_extension)) {
                        echo "<script>alert('File Tidak Didukung'); window.location='dashboard.php?hal=tentang'</script>";
                    } else {
                        if ($size_foto_tentang < 409600){
                            $nama_foto_tentang = $rand.'_'.$foto_tentang;
                            unlink($path_foto_tentang);
                            move_uploaded_file($_FILES['foto_tentang']['tmp_name'], '././foto_tentang/'.$nama_foto_tentang);
                            mysqli_query($koneksi, "UPDATE tbl_tentang SET konten_tentang='$konten_tentang', foto_tentang='$nama_foto_tentang' WHERE id_tentang='$id_tentang'");
                            echo "<script>alert('Konten dan Foto Profil Berhasil Diubah'); window.location = 'dashboard.php?hal=tentang'</script>";
                        } else {
                            echo "<script>alert('Ukuran Foto Terlalu Besar'); window.location = 'dashboard.php?hal=tentang'</script>";
                        }
                    }
                }
            }
            ?>
        </div>
    </div>
</div>
